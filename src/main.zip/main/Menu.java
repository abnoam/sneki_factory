package main;

import java.util.Scanner;

public class Menu
{
    private final FactoryManager manager;
    private final Scanner scanner;

    public Menu(FactoryManager manager)
    {
        this.manager = manager;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        boolean running = true;
        while (running)
        {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Client Management");
            System.out.println("2. Order Management");
            System.out.println("3. Inventory Management");
            System.out.println("4. Distributor Management");
            System.out.println("0. Exit");

            String choice = scanner.next();
            switch (choice)
            {
                case "1": clientMenu(); break;
                case "2": orderMenu(); break;
                case "3": inventoryMenu(); break;
                case "4": distributorMenu(); break;
                case "0": running = false; break;
                default: System.out.println("Invalid option.");
            }
        }
    }

    private void clientMenu() {
        System.out.println("\n--- Client Management ---");
        System.out.println("1. Add Client\n2. Delete Client\n3. Edit Client\n4. Back");
        String choice = scanner.next();

        switch (choice)
        {
            case "1":
                // לוגיקת הוספה...
                break;
            case "2":
                System.out.print("Enter ID to delete: ");
                int id = scanner.nextInt();
                manager.deleteClient(id);
                System.out.println("Client deleted (if it existed).");//im afk
                break;
            case "3":
                // עריכה...
                break;
            case "4": return; // חוזר לתפריט הראשי
        }
    }

    private void orderMenu()
    { /* לוגיקה לניהול הזמנות */ }
    private void inventoryMenu()
    { /* לוגיקה לניהול מלאי */ }
    private void distributorMenu()
    { /* לוגיקה לניהול מפיצים */ }
}